
describe('Go to site', () => {
    it('Open page with images', () => {
        cy.visit('https://the-internet.herokuapp.com/broken_images')
    })
})

describe('Check if images is not broken', () => {
   // not visible 1,2 images
    it('check image if visible1', () => {
        cy.get('img[src="hjkl.jpg"]').should('be.visible')
        .and($img => expect($img[0].naturalWidth).to.be.gt(0))
    })
    it('check image if visible2', () => {
        cy.get('img[src="asdf.jpg"]').should('be.visible')
        .and($img => expect($img[0].naturalWidth).to.be.gt(0))
    }) 

   // visible #3 image
    it('check image if visible3', () => {
        cy.get('img[src="img/avatar-blank.jpg"]').should('be.visible')
        .and($img => expect($img[0].naturalWidth).to.be.gt(0))
    })
   
})
//second check with diferent func.
describe('Check if images is not broken #2', () => {
// 1. Select all image (`img`) elements on the page.
it('check image if visible', () => {
    cy.get('img').each(($img) => {
    // 2. Scroll the image into view and check if it's visible.
    cy.wrap($img).scrollIntoView().should('be.visible');
    let image = cy.wrap($img).scrollIntoView().should('be.visible');
    if( image == true){
        console.log($img);
    }
  
    // // 3. Ensure the natural width and height is greater than 0.
    expect($img[0].naturalWidth).to.be.greaterThan(0);
    // expect($img[0].naturalHeight).to.be.greaterThan(0);
  })
})
})
