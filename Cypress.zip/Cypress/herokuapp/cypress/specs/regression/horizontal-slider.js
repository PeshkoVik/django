describe('Open page', () => {
    it('go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/horizontal_slider')
    })
})

describe('Working with slider', () => {
    
        it("using arrow keys", () => {
          
          cy.get('.sliderContainer > input').click()  
          cy.get('.sliderContainer > input').type('{rightarrow}.repeat(10)')
          
          // cy.get('.sliderContainer')
            //   .should('have.attr', 'range', 0)
            //   .type(arrows)
          
            // cy.get('.sliderContainer')
            //   .should('have.attr', 'range', 5)
          
          //scrollTo
    })
})