describe('CGo to page',() => {
    it('Open Page', () => {
        cy.visit('https://the-internet.herokuapp.com/forgot_password')
    })
})
describe('Check forgot function', () => {
    it('put @mail to field', () => {
        cy.get('#email').type('ggg@gmail')
        cy.get('#form_submit').click()
    }) 
})