describe('Open page JQueryUI menu', () => {
    it('Go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/jqueryui/menu')
    })
})

describe('Working with Menu', () => {
   

    it('Focus on Menu and go excel', () => {
        cy.contains('Enable').click()
        cy.contains('Downloads').click()
        cy.contains('Excel').click('{timeout: 25000}')
      
    })
})  

//   /**      Fixing page loading for 60s
//    * Show the CSV in the screen by changing the headers to not fail by reading responses with content-type other than text/html
//    */
//   openCSVWithInterceptionWorkAround() {
//     cy.get('#downloadBtn')
//       .invoke('attr', 'href')
//       .then(($href) => {
//         cy.intercept(
//           'GET',
//           $href, // URL
//           (req) => {
//             req.continue((res) => {
//               // Change the response headers that would prevent the request from being loaded in Cypress.
//               // @ts-ignore
//               res.headers['content-disposition'] = undefined
//               res.headers['content-type'] = 'text/html'
//             })
//           }
//         ).as('exportCsv')

//         cy.forcedWait(2000) // Give some time before clicking
//         cy.get(selectors.exportIcon).click()
//         cy.wait('@exportCsv')
//       })
//   }

//   /**
//    * This method exports the csv file by sending a request rather than clicking in the export csv button.
//    * This approach avoids the page load issue to get stuck. Also, it allow us to control the file name output from the csv that is being downloaded.
//    *
//    *
//    * @param {String} filePathToSaveTheCsv The file path name you can choose to save the csv file. E.g "cypress/downloads/Expense Detail Report.csv"
//    */
//   exportCsvWithRequest(filePathToSaveTheCsv) {
//     cy.get('#downloadBtn')
//       .invoke('attr', 'href')
//       .then(($href) => {
//         cy.request($href) => {
//           cy.writeFile(filePathToSaveTheCsv, response.body)
//         })
//       })
//   }