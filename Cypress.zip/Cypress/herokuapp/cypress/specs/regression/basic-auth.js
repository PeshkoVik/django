describe( 'Login with popup form', () => {
    
    it('open form', () => {
    cy.visit('https://admin:admin@the-internet.herokuapp.com/');
    
        
    cy.visit('https://admin:admin@the-internet.herokuapp.com/basic_auth/');
        
    })

     it('Fill form', () => {
       // cy.type('{enter}');

        // cy.window().then(function($promptelement){   // for prompt-type alert

        //     cy.stub($promptelement, "Username").returns("admin");
 
    //    cy.contains('Click for JS Prompt').click()
 
    //    cy.get('#result').should('contain','You entered: Hello')

      // });
     });
 });

 