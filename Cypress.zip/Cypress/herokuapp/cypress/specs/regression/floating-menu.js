describe( 'Working with floating menu', () => {
    it('Open page', () => {
        cy.visit('https://the-internet.herokuapp.com/floating_menu')
    })
})

describe('Check menu', () => {
    it('check botton Home', () => {
        cy.get('#menu > ul > li:nth-child(1) > a').click()
        //https://the-internet.herokuapp.com/floating_menu#home
        cy.wait(2000);
        cy.location('href').should('eq', 'https://the-internet.herokuapp.com/floating_menu#home');
    })
        it('check botton News', () => {
            cy.get('#menu > ul > li:nth-child(2) > a').click()
        })
        it('check botton Contact', () => {
            cy.get('#menu > ul > li:nth-child(3) > a').click()
            cy.get('#menu > ul > li:nth-child(3) > a').should('contain.text', 'Contact')
            cy.get('#menu > ul > li:nth-child(3) > a').should('be.visible')
        })
})


   
