describe('Open page JS Alerts', () => {
    it('Go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts')
    })
})

describe('Check Alert buttons', () => {
    it('Click for JS Alert', () => {
        
        cy.contains('Click for JS Alert').click()

    })
})
//click for confirmation button 
describe('Test Js confirm true', function () {
    // test case
    it("Scenario 1", function () {
       //URL launched
       cy.visit("https://the-internet.herokuapp.com/javascript_alerts")
       //fire confirm browser event and accept
       cy.get(':nth-child(2) > button').click()
       cy.on("window:confirm", (t) => {
          //verify text on pop-up
          expect(t).to.equal("I am a JS Confirm");
       });
    });
 });
// cancelle botton Click for confirm
describe('Test Js confirm false', function () {
    // test case
    it("Scenario 1", function () {
       // URL launched
       cy.visit("https://the-internet.herokuapp.com/javascript_alerts")
       //fire confirm browser event
       cy.on("window:confirm", (s) => {
          return false;
       });
       // click on Click for JS Confirm button
       cy.get(':nth-child(2) > button').click()
       // verify application message on Cancel button click
       cy.get('#result').should('have.text', 'You clicked: Cancel')
    });
 });

//test Promp input some text and check
 describe('Test Js prompt', function () {
    // test case
    it("Scenario 1", function () {
       //URL launch
       cy.visit("https://the-internet.herokuapp.com/javascript_alerts")
       //handling prompt alert
       cy.window().then(function(p){
          //stubbing prompt window
          cy.stub(p, "prompt").returns("Test ppp");
          // click on Click for JS Prompt button
          cy.get(':nth-child(3) > button').click()
          // verify application message on clicking on OK
          cy.get('#result').contains('You entered: Test ppp')
       });
    });
 });   
