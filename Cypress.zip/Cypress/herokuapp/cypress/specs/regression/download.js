describe('Loading/downloading files', () => {
    it('visit to downloding page', () => {
        cy.visit('https://the-internet.herokuapp.com/download')
    })

    it('Loading', () => {
        it('download file in mentioned dir', () => {
      cy.downloadFile('https://the-internet.herokuapp.com/download/TextDoc.txt', './downloads/', 'TextDoc.txt')
      //cy.readFile("./Downloads/test.doc").should('contain', 'Text for comparison')
    })
    })
})

