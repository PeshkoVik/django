describe('Open page Inputs', () => {
    it('Go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/inputs')
    })
})

describe('Working with Inputs Field', () => {
    it('Type some number and moveDown number -1', () => {
        cy.get('#content > div > div > div > input[type=number]').click()
        .type('200{downarrow}')
    })
})