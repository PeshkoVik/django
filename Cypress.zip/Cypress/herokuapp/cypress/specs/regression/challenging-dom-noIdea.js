describe('Go to site', () => {
    it('Open page with images', () => {
        cy.visit('https://the-internet.herokuapp.com/challenging_dom')
    })
})