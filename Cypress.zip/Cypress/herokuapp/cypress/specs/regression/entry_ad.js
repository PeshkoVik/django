describe('Open page', () => { 
    it('Passes page', () => {
      cy.visit('https://the-internet.herokuapp.com/entry_ad')
      })
  })

  describe('Checkin entry ad', () => {
    it('close window', () => {
      cy.get('#modal > div.modal > div.modal-footer').click();
      cy.wait(8000)
    })
  })
//   describe('reEntry ad', () => {
//     it('open window', () => {
//       cy.get('#restart-ad').click()
//     })
// })