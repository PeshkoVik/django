describe ('Open page', () => {
    it('visit to link', () => {
        cy.visit('https://the-internet.herokuapp.com/geolocation')
    })
})

describe('check geolocation', () => {
    it('Click on botton Check geolocation', () => {
        cy.get('#content').contains('Where am I?').click()
    })
    it('check if returning data visible', () => {
        cy.get('#lat-value').should('be.visible')
        cy.get('#long-value').should('be.visible')
    })
})

