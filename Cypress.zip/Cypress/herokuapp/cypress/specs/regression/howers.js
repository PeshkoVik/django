
describe('Open page', () => {
    it('go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/hovers')
    })
})

describe('check info and images', () => {
    it('check if info visible after focus on image', () => {
        //need real install cypress-real-events patch
        cy.get('#content > div > div:nth-child(3) > img').realHover('mouse').wait(5000)
        


        
   
    })
})

