describe('Open page', () => { 
    it('Passes', () => {
      cy.visit('https://the-internet.herokuapp.com/dropdown')
      })
  })

  describe('Select line', () => {
    it('select first line', () => {
        cy.get('#dropdown').select(1);
    })
    it('select second line', () => {
        cy.get('#dropdown').select(2);
    })

  })
  
    