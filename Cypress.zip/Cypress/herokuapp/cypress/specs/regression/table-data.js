describe('Open page Data Table', () => {
    it('Go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/tables')
    })
})

describe('Check Table data', () => {
    it('Checking first table', () => {
        cy.get('#table1 > tbody > tr:nth-child(1) > td:nth-child(1)').should('have.text','Smith')
       // #table1 > tbody > tr:nth-child(1) > td:nth-child(1)
       // #table2 > tbody > tr:nth-child(1) > td.dues
        
    })
})