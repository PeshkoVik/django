describe('Open page Large and d', () => {
    it('Go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/large')
    })
})

describe('Check some numbers', () => {
    
    it('Check some numbers from table', () => {
        
       cy.get('#large-table > tbody > tr.row-21 > td.column-8').should('have.text','21.8')
       cy.get('#large-table > tbody > tr.row-21 > td.column-8').invoke('text').should('eq','21.8')

      
    })
})