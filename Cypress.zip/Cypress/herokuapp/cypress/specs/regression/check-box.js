describe('Go to site', () => {
    it('Open page with images', () => {
        cy.visit('https://the-internet.herokuapp.com/checkboxes')
    })
})

// all check
describe('Working with check', () => {
    it('change value of  checkboxes', () => {
        cy.get('input[type="checkbox"]').check()
    })
})
//all uncheck
describe('Working with uncheck', () => {
    it('change value of checkboxes', () => {
        cy.get('input[type="checkbox"]').uncheck()
        
    })
//     it('checkbox with assertio', () => {
//         //checkbox with assertio
// cy.get('input[type="checkbox"]').check().should('be.checked')
//     })
 })

//       //checkbox with assertio
//cy.get('input[type="checkbox"]').check().should('be.checked')
//       //identify checkbox with class with assertion
//       cy.get('.VfPpkd-muHVFf-bMcfAe').uncheck().should('not.be.checked')
