describe('Open page', () => {
    it('go to page', () => {
        cy.visit('https://the-internet.herokuapp.com/infinite_scroll')
    })
})

describe('check infinity scroll', () => {
    it('scroll page', () => {
        cy.get('#page-footer').scrollIntoView()
        cy.wait(5000)
        cy.get('#page-footer').scrollIntoView()
        cy.wait(5000)
        cy.get('#page-footer').scrollIntoView()
   
    })
})