describe('Open page', () => { 
  it('Passes', () => {
    cy.visit('https://the-internet.herokuapp.com/')
    })
})

   describe('Check content', () => {
    it('Content must be visible', () => {
        cy.get('#content').should('be.visible');
        })
    })