
const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config){
      config.env =process.env
      return config;
    },
    "viewportHeight": 1000,
    "viewportWidth": 1280,
    testIsolation: false,
    "videoUploadOnPasses": false,
    "defaultCommandTimeout": 8000,
    "chromeWebSecurity": false,
    "specPattern": "cypress/specs/**/*.js",
    //"screenshotsFolder": "cypress/temp/screenshots",
    //"videosFolder": "cypress/temp/videos",
    "fixturesFolder": "cypress/data",
    "reporter": "junit",
    "baseUrl": "https://the-internet.herokuapp.com/",
   "reporterOptions": {
     "mochaFile": "cypress/temp/reports/report-[hash].xml",
     "toConsole": true
    
   },
    "watchForFileChanges": false,
  },
}); 