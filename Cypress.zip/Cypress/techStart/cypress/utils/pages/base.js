import base from  './base';

const selectors = {
    logo: '#logo',
}

const expected = {
    altLogo: 'Logo',
    maxInputLength: '100',

}

const checkAltLogo = () => {
    cy.get(selectors.logo).should('have.attr', 'alt', expected.altLogo);
}

export default {
    ...selectors,
    expected,
    checkAltLogo,
}