import base from './base';

// selectors
 const selectors = { 
    page: '#login-page',
    email: '#username',
    loginBtn: '#btn-login',
    pass: '#pass',
    logout: '#btn-logout',
 }

// expected results
const expected = {
    ...base.expected,
    blueColor: 'rgb(0, 123, 255)',
    loginBtnText: 'Login',
    emailPlaceholder: 'Email *',
    emailFieldType: 'email',
    passPlaceholder: 'Password',
    passFieldType: 'password',
}

// functions
const openPage = () => cy.visit('/');
//const checkAltLogo = () => console.log('Hellow word!');

const succesesfullLogin = () => {
    cy.get(selectors.email).type('mafplaceqauser@gmail.com');
    cy.get(selectors.pass).type('mn49j6qw6o');
    cy.get(selectors.loginBtn).click();

}

export default {
    ...selectors,
    ...base,
    expected,
    openPage,
    succesesfullLogin,
    //checkAltLogo,
}