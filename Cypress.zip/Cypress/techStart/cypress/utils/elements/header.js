// selector
const selectors = {
    header: '#header',
    buttonAll: '#btn-all',
}
