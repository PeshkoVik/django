describe('Elements', () => {
    before(() => cy.visit('/users'));

    it('Table has 10 rows', () => {
        cy.get('.players-row.player-table-row').should('have.length', 0)

    }) 
})

describe('Functionality', () => {
    before(() => {
      //  cy.get('.page-link').last().invoke('text').then(text => lastNumber = text)
    });

    it ('Search', () => {
        cy.get('.players-row').each(el => {
            expect(el.text()).to.contain('poi');
        })
      //  cy.get('.players-row').should('contain.text', 'poi');
    })
}
)