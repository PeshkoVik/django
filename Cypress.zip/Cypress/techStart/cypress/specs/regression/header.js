import Login from '../../utils/pages/login';

describe('elements', () => {

    before(() => {
        Login.openPage();
    });

    it('Login Page is displayed', () => {
        cy.get(Login.page).should('be.visible');
    })

})