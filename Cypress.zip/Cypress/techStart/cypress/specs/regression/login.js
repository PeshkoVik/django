import Login from '../../utils/pages/login';

describe('elements', () => {

    before(() => {
        Login.openPage();
    });

    it('Login Page is displayed', () => {
        cy.get(Login.page).should('be.visible');
    })

})

describe ('Values', () => {
    it('Image has alt="Logo', () => {
    Login.checkAltLogo();
    })
})

describe ('Button Login', () => {
    it('Image has alt="Logo', () => {
    cy.get(Login.loginBtn).should('be.visible');
    cy.get(Login.loginBtn).should('have.text', Login.expected.loginBtnText);
    cy.get(Login.loginBtn).should('have.css', 'background-color',Login.expected.blueColor);
    })
})

describe ('mail, password have fields, values', () => {
    const maxValue = 100
    it('Email field has Max length', () => {
        cy.get(Login.email).should('have.attr','maxlength', maxValue);
    })

    it('Email field has text Email', () => {
        cy.get(Login.email).should('have.attr','placeholder', Login.expected.emailPlaceholder);
    })

    it('Password field initially is empty, and has Max length limit', () => {
       cy.get(Login.pass).should('not.have.value');
       const maxValue = 100
       const inCorrectValue = "i".repeat(102)
       cy.get(Login.pass).type(inCorrectValue).invoke('val').should('have.length', maxValue);
       //cy.get(selectors.email).invoke('val').should('have.length', expected.emailMaxInputLength);
     } )

     it('Login', () => {
        cy.get(Login.email).type('mafplaceqauser@gmail.com');
        cy.get(Login.pass).clear().type('mn49j6qw6o');
        cy.get(Login.loginBtn).click();
     })

     describe('Logout from page', () => {
        it('Logout', () => {
       cy.get(Login.logout).should('be.visible');
       cy.get(Login.logout).click();
     })
    })
    
} )

//loginEmail : 'mafplaceqauser@gmail.com',
//loginPassword : 'mn49j6qw6o';