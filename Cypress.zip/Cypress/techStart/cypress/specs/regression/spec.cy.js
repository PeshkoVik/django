//const { ceil } = require("cypress/types/lodash");

describe ('Elements', () => {
    before(() => {
        cy.visit('/');
    });

    it('Login Page is displayed', () => {
       cy.get('#login-page').should('be.visible');
    })
   
})

describe ('Values', () => {
    it('Image has alt="Logo', () => {
    cy.get('#logo').should('have.attr', 'alt','Logo');
    })
})

describe ('Button Login', () => {
    it('Image has alt="Logo', () => {
    cy.get('#btn-login').should('be.visible').and('equal', '');
    cy.get('#btn-login').should('have.text', 'Login');
    cy.get('#btn-login').should('have.css', 'background-color','rgb(0, 123, 255)');
    })
})

describe ('mail, password have fields, values', () => {
    const maxValue = 100
    it('Email field has Max length', () => {
        cy.get('#username').should('have.attr','maxlength', maxValue);
    })
    it('Email field has text Email', () => {
        cy.get('#username').should('have.attr','placeholder', 'Email *');
    })

    it('Password field initially is empty, and has Max length limit', () => {
       cy.get('#pass').should('not.have.value');
       const maxValue = 100
       const inCorrectValue = "i".repeat(102)
       cy.get('#pass').type(inCorrectValue).invoke('val').should('have.length', maxValue);
       //cy.get(selectors.email).invoke('val').should('have.length', expected.emailMaxInputLength);
     } )

     it('Login', () => {
        cy.get('#username').type('mafplaceqauser@gmail.com');
        cy.get('#pass').clear().type('mn49j6qw6o');
        cy.get('#btn-login').click();
        
     })

     describe('Logout from page', () => {
        it('Logout', () => {
       cy.get('#btn-logout').should('be.visible');
       cy.get('#btn-logout').click();
     })
    })
    
} )

//loginEmail : 'mafplaceqauser@gmail.com',
//loginPassword : 'mn49j6qw6o';