import axios from 'axios';

describe( 'User', () => {
    let response
    let id 

    it('Greate user', async () => {
        response =  await axios.post(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/`, {

        "firstName": "123bbBen",
        "lastName": "123jjJ",
        "email": "123qqqwert@gmail.com",
        "pass": "123qqqwert",
        "admin": false,
        "nickName": "123qqBJ",
        "moderator": false,
        "sex": "man",
        "lastTimePaid": 0
        });

        expect(response.data.user._id).to.exist
        id = response.data.user._id;
   
});
    it('Get all users', async () => {
        response =  await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/`)
       
        let myUser = response.data.find(el => el._id === id)
             expect(myUser).exist
            // id = response.data.user._id;
        });
        it('User update', async () => {
            response =  await axios.patch(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/${id}`, {
    
            "firstName": "bb1BBen",
            "lastName": "jj1JJ",            
            });
            expect(response.status).to.eq(200)
        });

            it('Get user', async () => {
                response =  await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/${id}`) 
    expect(response.data.firstName).to.eq("bb1BBen")
    expect(response.data.lastName).to.eq("jj1JJ")
            }); 

            it('Delete the user', async () => {
                response =  await axios.delete(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/${id}`) 
    expect(response.status).to.eq(200);
            }); 

            it('Check the user not exist', async () => {
                response =  await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/`) 
                let myUser = response.data.find(el => el === id)
                expect(myUser).to.not.exist
   
            }); 

});