import axios from 'axios';  
const id = '6357745c2da3ee33ac58974f';
const pass = 'mn49j6qw6o';

describe('Axios', () => {
    let response
    before(async () => {
        response =  await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/${id}?pass=${pass}`);
    })

       it('status is 200', () => {
       expect(response.status).to.eq(200);
    })

    it('messege is "authorized', () => {
        console.log(response)
        expect(response.data.message).to.eq('authorized');
    })

    it('token is valid string', () => {
        expect(response.data.token).to.be.a('string');
        expect(response.data.token.length > 0).to.eq(true);
    })

    it('id is valid', () => {
        expect(response.data.user._id).to.eq(id);
    })

    it('email is valid', () => {
        expect(response.data.user.email).to.eq('mafplaceqauser@gmail.com');
    })
});

    describe('Authorization negativ', () => {

        it('Id is incorect', async () => {
            try { 
                await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/123?pass=${pass}`)
            } catch (error) {
            expect(error.response.status).to.eq(404);
            expect(error.response.data.message).to.eq('no user with specified id');
            expect(error.response.data.token).to.not.exist;
         }
        })

        it('Password is incorect', async () => {
            try { 
                await axios.get(`https://maf-place-qa-srv.azurewebsites.net/mafia-users/${id}?pass=1244`)
            } catch (error) {
            expect(error.response.status).to.eq(401);
            expect(error.response.data.error).to.eq('unauthorized');
            expect(error.response.data.token).to.not.exist;
         }
        })
});