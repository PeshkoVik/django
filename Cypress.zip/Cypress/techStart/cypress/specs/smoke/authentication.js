import Login from "../../utils/pages/login"
import Ratings from "../../utils/pages/ratings"
import Header from "../../utils/elements/header"
import Forgot from "../../utils/pages/forgot"

describe('Autorization', () => {
    before(() => {
        Login.openPage();
    })

    it('Login', () => {
        Login.succesesfullLogin();

    })

    it('Logout', () => {

    })

    it('forgot password', () => {

    })
})