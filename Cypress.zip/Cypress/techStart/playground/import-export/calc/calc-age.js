export default function(birthYear, thisYear){
    return thisYear - birthYear;
}