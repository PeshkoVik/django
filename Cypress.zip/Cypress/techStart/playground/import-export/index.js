import a, { firstName } from './name.js';
import calcAge from './calc/calc-age.js';
console.log(a);
console.log(firstName);
console.log(calcAge(1993,2023));