export const firstName = 'Bob'
const lastName = 'Jones'
export default `${firstName} ${lastName}`;
 
