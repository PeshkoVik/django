
import axios from 'axios'
describe('Working with client daley', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/clientdelay')
    })

    it('Click on button and wait', () => {
       cy.get('#ajaxButton').click().wait(16000)
    })

    it('Check and click on button after delay',() => {
       cy.get('.bg-success').should('be.visible')
       cy.contains('Data calculated on the client side.').click()
    })
})

