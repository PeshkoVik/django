
import axios from 'axios'
describe('Working with click', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/click')
    })

    it('Click on button', () => {
       cy.get('#badButton').click()
    })
    it('Check button if green and click', () => {
        cy.get('#badButton').should('have.css','background-color','rgb(40, 167, 69)').click()
     })

    //rgb(0, 123, 255)
    //rgb(30, 126, 52)
})

