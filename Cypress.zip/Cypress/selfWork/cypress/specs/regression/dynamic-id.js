describe('Working with Dynamic IDs', () => {
    it('Open page with botton dynamic ID', () => {
        cy.visit('http://uitestingplayground.com/dynamicid')
    })

    it('Check and use botton with Dynamic ID', () => {
        cy.contains('Button with Dynamic ID').and('be.visible')
        cy.contains('Button with Dynamic ID').click()
    })
})

describe('Check if ID is not used for button identification', () => {
  
    it('Check if botton dynamic ID not the same', () => {
        cy.contains('button', 'Button with Dynamic ID').invoke('attr','id').then(($adynamicId) => {
            const adynamicId =  $adynamicId
            cy.visit('http://uitestingplayground.com/dynamicid')
            cy.contains('button', 'Button with Dynamic ID').invoke('attr','id').should('not.be.eq', adynamicId)
            cy.log('dynamicId')
        })
    })
})
