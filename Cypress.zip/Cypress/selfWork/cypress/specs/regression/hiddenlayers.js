import axios from 'axios'

describe('Working with hiddenlayers', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/hiddenlayers')
    })

    it('Click on button', () => {
        cy.get('#greenButton').click()
    })

    it('Click on button second time',async () => {
        try{
       cy.get('#greenButton').click()
        } catch (error){
            cy.log(error)
        }
       
    })
})

