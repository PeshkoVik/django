import axios from 'axios'
describe('Working with daley', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com')
    })

    it('Click on button', () => {
        cy.contains('Load Delay').click()
        cy.wait(8000)
    })

    it('Click on button after delay',() => {
       cy.contains('Button Appearing After Delay').click()
    })
})

