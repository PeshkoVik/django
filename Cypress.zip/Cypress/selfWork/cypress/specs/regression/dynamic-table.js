
describe('Working with Dynamic Table', () => {
   
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/dynamictable')
    })

    it('For Chrome process get value of CPU load', () => {
        cy.get('.bg-warning').invoke('text').then ( text1 => {
           
        cy.contains('span', 'Chrome').parent().within(() => {
         cy.contains('[role=cell]', '%').invoke('text').then((text2) => {
            expect(`Chrome CPU: ${text2}`).to.contains(text1) //compare  2 to 1 
            //expect(text1).to.contains(`Chrome CPU: ${text2}`)
                
        })
    })
}) 
})
})
         
            //cy.log(text2 + 'TEXT 2') 
         //cy.log(text1 + 'TEXT 1') 
        
//---------------------------------------------------------------------------------------
       



