describe('Working with Dynamic IDs', () => {
    it('Open page with botton dynamic ID', () => {
        cy.visit('http://uitestingplayground.com/verifytext')
    })

    it('Check and verifytext "Welcome UserName"', () => {
       // cy.get('.badge-secondary').contains('Welcome ').should('be.visible')
        cy.contains('*[class^="badge-secondary"]','Welcome UserName!').should('be.visible')
       // cy.contains('Button with Dynamic ID').click() 
    })
})

