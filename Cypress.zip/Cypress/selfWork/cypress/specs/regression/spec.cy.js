describe('Check Btns', () => {
    before ( () =>  cy.visit('http://uitestingplayground.com/visibility'));
    it('visible Btns', () => {
      cy.get('#hideButton').should('be.visible');
      cy.get('#removedButton').should('be.visible');
      cy.get('#zeroWidthButton').should('be.visible');
      cy.get('#overlappedButton').should('be.visible');
      cy.get('#transparentButton  ').should('be.visible');
      cy.get('#invisibleButton').should('be.visible');
      cy.get('#notdisplayedButton').should('be.visible');
      cy.get('#offscreenButton').should('be.visible');
      
    })
})

  describe('check if btn hide work', () => {
    it('mast click and will hide remove btn', () => {
    cy.get('#hideButton').click();
    cy.get('#hideButton').should('be.visible');
    //cy.get('#removedButton').should('be.visible');
    //cy.get('#zeroWidthButton').should('be.visible');
    cy.get('#overlappedButton').should('be.visible');
    //cy.get('#transparentButton  ').should('be.visible');
    //cy.get('#invisibleButton').should('be.visible');
    //cy.get('#notdisplayedButton').should('be.visible');
    cy.get('#offscreenButton').should('be.visible');
  })

})

// describe('check button remove', () => {
//   it('visible hide Btn', () => {
//     cy.get('#removedButton').should('be.visible');
//     cy.get('#removedButton').should('have.css', 'background-color', 'rgb(220, 53, 69)');
//   })
// })