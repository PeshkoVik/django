describe('Working with class attr', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/classattr')
    })

    it('Click on blue btn', () => {
       
       cy.get('.btn-primary').should('have.css','background-color', 'rgb(0, 123, 255)').click()
      
    })
})