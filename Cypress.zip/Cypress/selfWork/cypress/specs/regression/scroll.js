
describe('Working with scrollbar', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/scrollbars')
    })

    it('Scroll botton to visible view and click', () => {
        cy.get('#hidingButton').scrollIntoView()
        cy.get('#hidingButton').click()
    })

    it('Check botton if stay in visible area', () => {
        cy.get('#hidingButton').should('be.visible')
    })
})


