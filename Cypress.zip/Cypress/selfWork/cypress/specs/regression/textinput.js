
describe('Working with input', () => {
    it('Open page', () => {
        cy.visit('http://uitestingplayground.com/textinput')
    })

    it('Type text to field and press botton', () => {
        cy.get('#newButtonName').type('new botton')
       cy.get('#updatingButton').click()
    })
    it('Check button has new name', () => {
        cy.get('#updatingButton').should('have.text','new botton')
     })

    //rgb(0, 123, 255)
    //rgb(30, 126, 52)
})


