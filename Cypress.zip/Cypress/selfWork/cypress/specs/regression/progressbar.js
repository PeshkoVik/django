import axios from'axios'

describe('Working with progressbar', () => {
    it('Open page with botton dynamic ID', () => {
        cy.visit('http://uitestingplayground.com/progressbar')
        cy.get('#startButton').click()
    })

   

    it('Check progressbar, star and stop when value is 75%', () => {

      cy.get('#progressBar').invoke('attr', 'aria-valuenow').then((value) => {
      cy.log(value)
      
     if(value < 75){
        stopIfValue75()
     } else if(value < 75){
        stopIfValue75()
     } else {
     expect(value).to.be.eq('75')
      }
     })
    })

//function for click stop button when value is 75
    const stopIfValue75 = () => {
       cy.get('#progressBar').should('have.attr', 'aria-valuenow','75')
       cy.get('#stopButton').click()
          }
        })



            
        

    
// cy.waitUntil(() => elem.invoke('attr', 'value').then((val) => val != initialVal))
// it('Check progressbar, star and stop when value is 75%', () => {
//     cy.get('#progressBar').should('be.visible')
//     cy.get('#progressBar').invoke('attr', 'aria-valuenow').then((value) => {
//       cy.log(value)
//       cy.get('#startButton').click()
//      if(value < 75){
//       return value;
//      }else{
//      expect(value).to.be.eq('75')
//      cy.get('#stopButtonn').click()
//      cy.log(value) 
//    }
//   })
// })

//  it('Check progressbar, star and stop when value is 75%', () => {
//         cy.get('#startButton').click()
        
//             cy.get('#progressBar').invoke('attr', 'aria-valuenow').then((initialVal) => {
//                 cy.waitUntil(() => cy.get('#progressBar').invoke('attr', 'value').then((val) => val != initialVal))
//             cy.get('#stopButton').click()

//             })
//         })


///////////////////////////
//  it('Check progressbar, star and stop when value is 75%', async() => {
//         try{

//         await axios.get('#progressBar').invoke('attr', 'aria-valuenow')
//         } catch(value) {
//             expect(value).to.eq(75);
//              cy.get('#stopButtonn').click()
//         }


//        })
